<!-- container-scroller -->
<!-- plugins:js -->
<script src="assets/vendors/base/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- inject:js -->
<script src="assets/js/off-canvas.js"></script>
<script src="assets/js/hoverable-collapse.js"></script>
<script src="assets/js/template.js"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="assets/js/file-upload.js"></script>
<!-- End custom js for this page-->

<script src="assets/js/parsley.min.js"></script>
<script src="assets/js/datatables.min.js"></script>